# -*- coding: utf-8 -*-
"""
Joey's Acoustic Corner (Kodi)
- Pulls ONE shared list from your Netlify JSON: /episodes.json
- Shows all multi-track items as a folder of individual tracks (no stitched queues → no Kodi crash)
- If an episode has a Brad Encore (encore.url + encoreAfterTrackIndex), Kodi shows it as Track 4 (Encore) ✅
- Playlists are SKIPPED entirely (goodbye KISS API headache) ✅
"""

import sys
import json
import re
import urllib.request
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin


HANDLE = int(sys.argv[1])

# ====== CHANGE THIS to your live Netlify site ======
SITE = "https://mellifluous-tanuki-51d911.netlify.app"

# ONE source of truth for BOTH site + Kodi:
# Put this file at site root: /episodes.json
EP_URL = SITE + "/episodes.json"

UA = "Kodi/21 JoeysAcousticCorner"

# ====== FALLBACK (if JSON is down) ======
FALLBACK_EPISODES = [
    ("Nirvana — MTV Unplugged (Full Session)", "https://youtu.be/pOTkCgkxqyg"),
    ("Alice In Chains — MTV Unplugged (Full Session)", "https://youtu.be/Jprla2NvHY0"),
    ("Pearl Jam — MTV Unplugged (Full Session)", "https://youtu.be/P9fPF204icg"),
]


# ---------- Basics ----------
def log(msg):
    xbmc.log(f"[JAC] {msg}", xbmc.LOGINFO)

def notify(msg):
    xbmcgui.Dialog().notification("Joey’s Acoustic Corner", msg, xbmcgui.NOTIFICATION_INFO, 4000)

def http_get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=25) as resp:
        data = resp.read().decode("utf-8")
        return json.loads(data)

def safe_text(v):
    return "" if v is None else str(v)

def yt_id_from_url(url):
    if not url:
        return None

    # youtu.be/ID
    m = re.search(r"youtu\.be/([A-Za-z0-9_\-]+)", url)
    if m:
        return m.group(1)

    # youtube.com/watch?v=ID
    m = re.search(r"[?&]v=([A-Za-z0-9_\-]+)", url)
    if m:
        return m.group(1)

    # youtube.com/embed/ID
    m = re.search(r"/embed/([A-Za-z0-9_\-]+)", url)
    if m:
        return m.group(1)

    return None

def youtube_play_video(video_id):
    # Requires plugin.video.youtube installed
    return f"plugin://plugin.video.youtube/play/?video_id={video_id}"

def add_dir(label, url, icon=None):
    li = xbmcgui.ListItem(label=label)
    if icon:
        li.setArt({"thumb": icon, "icon": icon})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

def add_playable(label, path, icon=None):
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    if icon:
        li.setArt({"thumb": icon, "icon": icon})
    xbmcplugin.addDirectoryItem(HANDLE, path, li, isFolder=False)

def end_dir():
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# ---------- Encore helpers ----------
def has_encore(ep):
    try:
        mode = str(ep.get("mode", "")).lower()
        encore = ep.get("encore") or {}
        encore_url = encore.get("url")
        after_idx = ep.get("encoreAfterTrackIndex")
        return (mode == "queue" and bool(encore_url) and isinstance(after_idx, int))
    except Exception:
        return False

def encore_track(ep):
    encore = ep.get("encore") or {}
    url = encore.get("url")
    title = encore.get("title") or "Encore"
    vid = yt_id_from_url(url)
    if not vid:
        return None
    return {"title": f"Encore 🕯️ — {title}", "url": url, "__vid": vid}


# ---------- Data load ----------
def load_episodes():
    try:
        data = http_get_json(EP_URL)
        if isinstance(data, list):
            return data
        return None
    except Exception as e:
        log(f"JSON fetch failed: {e}")
        return None


# ---------- Routing helpers ----------
def build_url(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def parse_params():
    if len(sys.argv) <= 2 or not sys.argv[2]:
        return {}
    return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))


# ---------- UI ----------
def list_sessions():
    eps = load_episodes()
    if not eps:
        notify("Using fallback list (JSON not reachable).")
        for title, url in FALLBACK_EPISODES:
            vid = yt_id_from_url(url)
            if vid:
                add_playable(title, youtube_play_video(vid))
        end_dir()
        return

    for idx, ep in enumerate(eps):
        title = ep.get("title") or "Untitled"
        artist = ep.get("artist")
        year = ep.get("year")
        mode = str(ep.get("mode", "")).lower()
        tracks = ep.get("tracks", []) or []

        # ✅ Skip playlists completely (KISS removed from Kodi)
        if mode == "playlist":
            continue

        label_bits = [title]
        meta = " • ".join([b for b in [safe_text(artist), safe_text(year)] if b])
        if meta:
            label_bits.append(f"({meta})")
        label = " ".join(label_bits)

        # Single item → play immediately
        if len(tracks) <= 1:
            if not tracks:
                continue
            vid = yt_id_from_url((tracks[0] or {}).get("url", ""))
            if not vid:
                continue
            add_playable(label, youtube_play_video(vid))
            continue

        # Multi-track → open folder (NO stitched queue)
        add_dir(label, build_url(action="episode", idx=str(idx)))

    end_dir()


def list_episode(idx_str):
    eps = load_episodes()
    if not eps:
        notify("JSON not reachable.")
        end_dir()
        return

    try:
        idx = int(idx_str)
        ep = eps[idx]
    except Exception:
        notify("Episode not found.")
        end_dir()
        return

    title = ep.get("title") or "Session"
    tracks = ep.get("tracks", []) or []

    # Show each track as a selectable playable item
    for i, t in enumerate(tracks, start=1):
        url = (t or {}).get("url", "")
        vid = yt_id_from_url(url)
        if not vid:
            continue
        tname = (t or {}).get("title") or f"Track {i}"
        add_playable(f"{i}. {tname}", youtube_play_video(vid))

    # ✅ If Brad encore exists, show it as Track 4 (or last) in Kodi
    if has_encore(ep):
        et = encore_track(ep)
        if et:
            add_playable(f"{len(tracks)+1}. {et['title']}", youtube_play_video(et["__vid"]))

    end_dir()


def router():
    p = parse_params()
    action = p.get("action")

    if action == "episode":
        return list_episode(p.get("idx", "0"))

    return list_sessions()


if __name__ == "__main__":
    router()
